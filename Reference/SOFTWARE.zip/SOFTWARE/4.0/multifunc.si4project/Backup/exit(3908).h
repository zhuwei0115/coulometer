#ifndef __EXIT_H
#define __EXIT_H

void EXTIX_Init(void);
void EXTI9_5_IRQHandler(void);


#endif
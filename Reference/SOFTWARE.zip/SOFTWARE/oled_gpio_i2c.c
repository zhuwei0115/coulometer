/********************************************************************

            Filename: oled_gpio_i2c.c

         Description: 
                      msp430 ��Ƭ��I2Cģ��
             Version: 1.0
             Created: 
            Revision: none

              Author: XiaoTan Luo
        Organization: ifreecomm.com

*********************************************************************/
#include "msp430x21x2.h"
#include "mcv3000_i2c.h"
#include "product_type.h"

#ifdef MCV3000_MINI_BOARD

#define SET_SCL_HIGH()    	{P3OUT |= BIT0;}
#define SET_SCL_LOW()		{P3OUT &= ~BIT0;}
#define SET_SCL_OUT()		{P3DIR |= BIT0;}
#define SET_SCL_REN()           {P3REN |= BIT0;}

#define SET_SDA_HIGH()    	{P3OUT |= BIT3;}
#define SET_SDA_LOW()		{P3OUT &= ~BIT3;}
#define	SET_SDA_OUT()		{P3DIR |= BIT3;}
#define SET_SDA_IN()            {P3DIR &= ~BIT3;}
#define SET_SDA_REN()           {P3REN |= BIT3;}
#define SET_SDA_NO_REN()		{P3REN &= ~BIT3;}

#define SET_LED_HIGH()          {P2OUT |= BIT3;}
#define SET_LED_LOW()		{P2OUT &= ~BIT3;}
#define	SET_LED_OUT()		{P2DIR |= BIT3;}

#define SET_RESET_HIGH()    {P1OUT |= BIT1;}
#define SET_RESET_LOW()		{P1OUT &= ~BIT1;}
#define	SET_RESET_OUT()		{P1DIR |= BIT1;}

#define SET_VDDH_HIGH()     {P2OUT |= BIT4;}
#define SET_VDDH_LOW()		{P2OUT &= ~BIT4;}
#define	SET_VDDH_OUT()		{P2DIR |= BIT4;}

#define SET_VDD_HIGH()      {P3OUT |= BIT7;}
#define SET_VDD_LOW()		{P3OUT &= ~BIT7;}
#define	SET_VDD_OUT()		{P3DIR |= BIT7;}

#define OLED_I2C_CMD_LEN	(8)
#define XLevelL				(0x00)
#define XLevelH				(0x10)
#define XLevel				((XLevelH & 0x0F) * 16 + XLevelL)
#define OLED_Max_COLUMN		(128)
#define OLED_MAX_ROW		(64)
#define	OLED_BRIGHTNESS		(0xBF)
#define	OLED_LINE_OF_PAGE	(8)

#define	OLED_DELAY_NUM_A	(40)
#define OLED_DELAY_NUM_C	(3)

extern unsigned char reg_val[I2C_REG_NUM];

#pragma memory = constseg(OLEDSEG)
const unsigned char Ascii_3[][16] = {
	
{0x00,0x00,0x07,0xF0,0x0F,0xF0,0x18,0x80,0x18,0x80,0x0F,0xF0,0x07,0xF0,0x00,0x00},		/*(1) A*/		
{0x00,0x00,0x1F,0xF0,0x1F,0xF0,0x11,0x10,0x11,0x10,0x1F,0xF0,0x0E,0xE0,0x00,0x00},		/*(2) B*/
{0x00,0x00,0x0F,0xE0,0x1F,0xF0,0x10,0x10,0x10,0x10,0x1C,0x70,0x0C,0x60,0x00,0x00},		/*(3) C*/
{0x00,0x00,0x1F,0xF0,0x1F,0xF0,0x10,0x10,0x18,0x30,0x0F,0xE0,0x07,0xC0,0x00,0x00},		/*(4) D*/
{0x00,0x00,0x1F,0xF0,0x1F,0xF0,0x11,0x10,0x11,0x10,0x11,0x10,0x10,0x10,0x00,0x00},		/*(5) E*/
{0x00,0x00,0x1F,0xF0,0x1F,0xF0,0x11,0x00,0x11,0x00,0x11,0x00,0x10,0x00,0x00,0x00},		/*(6) F*/
{0x00,0x00,0x0F,0xE0,0x1F,0xF0,0x10,0x10,0x10,0x90,0x1C,0xF0,0x0C,0xF0,0x00,0x00},		/*(7) G*/
{0x00,0x00,0x1F,0xF0,0x1F,0xF0,0x01,0x00,0x01,0x00,0x1F,0xF0,0x1F,0xF0,0x00,0x00},		/*(8) H*/
{0x00,0x00,0x00,0x00,0x10,0x10,0x1F,0xF0,0x1F,0xF0,0x10,0x10,0x00,0x00,0x00,0x00},		/*(9) I*/
{0x00,0x00,0x00,0x60,0x00,0x70,0x00,0x10,0x00,0x10,0x1F,0xF0,0x1F,0xE0,0x00,0x00},		/*(10)J*/
{0x00,0x00,0x1F,0xF0,0x1F,0xF0,0x01,0x00,0x07,0xC0,0x1E,0xF0,0x18,0x30,0x00,0x00},		/*(11)K*/
{0x00,0x00,0x1F,0xF0,0x1F,0xF0,0x00,0x10,0x00,0x10,0x00,0x10,0x00,0x10,0x00,0x00},		/* (12)L*/
{0x00,0x00,0x1F,0xF0,0x1F,0xF0,0x04,0x00,0x03,0x80,0x04,0x00,0x1F,0xF0,0x1F,0xF0},		/* (13)M */
{0x00,0x00,0x1F,0xF0,0x1F,0xF0,0x06,0x00,0x03,0x00,0x01,0x80,0x1F,0xF0,0x1F,0xF0},		/* (14)N */
{0x00,0x00,0x0F,0xE0,0x1F,0xF0,0x10,0x10,0x10,0x10,0x1F,0xF0,0x0F,0xE0,0x00,0x00},		/* (15)O */
{0x00,0x00,0x1F,0xF0,0x1F,0xF0,0x11,0x00,0x11,0x00,0x1F,0x00,0x0E,0x00,0x00,0x00},		/* (16)P */
{0x00,0x00,0x0F,0xE0,0x1F,0xF0,0x10,0x10,0x10,0x18,0x1F,0xFC,0x0F,0xE4,0x00,0x00},		/* (17)Q */
{0x00,0x00,0x1F,0xF0,0x1F,0xF0,0x11,0x00,0x11,0x80,0x1F,0xF0,0x0E,0x70,0x00,0x00},		/* (18)R */
{0x00,0x00,0x0C,0x20,0x1E,0x30,0x13,0x10,0x11,0x90,0x18,0xF0,0x08,0x60,0x00,0x00},		/* (19)S */
{0x00,0x00,0x10,0x00,0x10,0x00,0x1F,0xF0,0x1F,0xF0,0x10,0x00,0x10,0x00,0x00,0x00},		/* (20)T */
{0x00,0x00,0x1F,0xE0,0x1F,0xF0,0x00,0x10,0x00,0x10,0x1F,0xF0,0x1F,0xE0,0x00,0x00},		/* (21)U */
{0x00,0x00,0x1F,0xC0,0x1F,0xE0,0x00,0x30,0x00,0x30,0x1F,0xE0,0x1F,0xC0,0x00,0x00},		/* (22)V */
{0x00,0x00,0x1F,0x80,0x1F,0xF0,0x00,0x70,0x03,0x80,0x00,0x70,0x1F,0xF0,0x1F,0x80},		/* (23)W */
{0x00,0x00,0x18,0x70,0x1C,0xF0,0x07,0x00,0x03,0x80,0x1C,0xF0,0x18,0x70,0x00,0x00},		/* (24)X */
{0x00,0x00,0x1E,0x00,0x1F,0x00,0x01,0xF0,0x01,0xF0,0x1F,0x00,0x1E,0x00,0x00,0x00},		/* (25)Y */
{0x00,0x00,0x10,0x70,0x10,0xF0,0x11,0x90,0x13,0x10,0x1E,0x10,0x1C,0x10,0x00,0x00},		/* (26)Z */

{0x00,0x00,0x00,0x60,0x04,0xF0,0x04,0x90,0x04,0x90,0x07,0xF0,0x03,0xF0,0x00,0x00},		/* (27)a */
{0x00,0x00,0x1F,0xF0,0x1F,0xF0,0x04,0x10,0x04,0x10,0x07,0xF0,0x03,0xE0,0x00,0x00},		/* (28)b */
{0x00,0x00,0x03,0xE0,0x07,0xF0,0x04,0x10,0x04,0x10,0x06,0x30,0x02,0x20,0x00,0x00},		/* (29)c */
{0x00,0x00,0x03,0xE0,0x07,0xF0,0x04,0x10,0x04,0x10,0x1F,0xF0,0x1F,0xF0,0x00,0x00},		/* (30)d */
{0x00,0x00,0x03,0xE0,0x07,0xF0,0x04,0x90,0x04,0x90,0x07,0x90,0x03,0x80,0x00,0x00},		/* (31)e */
{0x00,0x00,0x01,0x00,0x0F,0xF0,0x1F,0xF0,0x11,0x00,0x11,0x00,0x11,0x00,0x00,0x00},		/* (32)f */
{0x00,0x00,0x03,0xE2,0x07,0xF2,0x04,0x12,0x04,0x12,0x07,0xFE,0x07,0xFC,0x00,0x00},		/* (33)g */
{0x00,0x00,0x1F,0xF0,0x1F,0xF0,0x04,0x00,0x04,0x00,0x07,0xF0,0x03,0xF0,0x00,0x00},		/* (34)h */
{0x00,0x00,0x04,0x10,0x04,0x10,0x37,0xF0,0x37,0xF0,0x00,0x10,0x00,0x10,0x00,0x00},		/* (35)i */
{0x00,0x00,0x00,0x02,0x04,0x02,0x04,0x02,0x37,0xFE,0x37,0xFC,0x00,0x00,0x00,0x00},		/* (36)j */
{0x00,0x00,0x1F,0xF0,0x1F,0xF0,0x00,0x80,0x01,0xC0,0x07,0x70,0x06,0x30,0x00,0x00},		/* (37)k */
{0x00,0x00,0x10,0x10,0x10,0x10,0x1F,0xF0,0x1F,0xF0,0x00,0x10,0x00,0x10,0x00,0x00},		/* (38)l */
{0x00,0x00,0x07,0xF0,0x07,0xF0,0x04,0x00,0x07,0xE0,0x04,0x00,0x07,0xF0,0x03,0xF0},		/* (39)m */
{0x00,0x00,0x07,0xF0,0x07,0xF0,0x04,0x00,0x04,0x00,0x07,0xF0,0x03,0xF0,0x00,0x00},		/* (40)n */
{0x00,0x00,0x03,0xE0,0x07,0xF0,0x04,0x10,0x04,0x10,0x07,0xF0,0x03,0xE0,0x00,0x00},		/* (41)o */
{0x00,0x00,0x07,0xFE,0x07,0xFE,0x04,0x10,0x04,0x10,0x07,0xF0,0x03,0xE0,0x00,0x00},		/* (42)p */
{0x00,0x00,0x03,0xE0,0x07,0xF0,0x04,0x10,0x04,0x10,0x07,0xFE,0x07,0xFE,0x00,0x00},		/* (43)q */
{0x00,0x00,0x07,0xF0,0x07,0xF0,0x01,0x00,0x02,0x00,0x06,0x00,0x06,0x00,0x00,0x00},		/* (44)r */
{0x00,0x00,0x03,0x10,0x07,0x90,0x04,0x90,0x04,0x90,0x04,0xF0,0x04,0x60,0x00,0x00},		/* (45)s */
{0x00,0x00,0x04,0x00,0x1F,0xE0,0x1F,0xF0,0x04,0x10,0x04,0x10,0x04,0x10,0x00,0x00},		/* (46)t */
{0x00,0x00,0x07,0xE0,0x07,0xF0,0x00,0x10,0x00,0x10,0x07,0xF0,0x07,0xF0,0x00,0x00},		/* (47)u */
{0x00,0x00,0x07,0xC0,0x07,0xE0,0x00,0x30,0x00,0x30,0x07,0xE0,0x07,0xC0,0x00,0x00},		/* (48)v */
{0x00,0x00,0x07,0xC0,0x07,0xF0,0x00,0x30,0x03,0xC0,0x00,0x30,0x07,0xF0,0x07,0xC0},		/* (49)w */
{0x00,0x00,0x06,0x30,0x07,0x70,0x01,0xC0,0x01,0xC0,0x07,0x70,0x06,0x30,0x00,0x00},		/* (50)x */
{0x00,0x02,0x07,0xE2,0x07,0xF2,0x00,0x16,0x00,0x1C,0x07,0xF8,0x07,0xE0,0x00,0x00},		/* (51)y */
{0x00,0x00,0x04,0x30,0x04,0x70,0x04,0xD0,0x05,0x90,0x07,0x10,0x06,0x10,0x00,0x00},		/* (52)z */
	
};

const unsigned char Ascii_2[][32] = {
	/* picture */
	{0x00,0x00,0x1F,0xE0,0x20,0x10,0x20,0x10,0x20,0x14,0x20,0x14,0x20,0x14,0x20,0x1C,0x21,0x1C,0x21,0x14,0x21,0x14,0x21,0x14,0x23,0x90,0x23,0x90,0x19,0x20,0x00,0x00},		/*	(1)send */		
	{0x00,0x00,0x00,0x00,0x07,0xE0,0x04,0x20,0x04,0x20,0x07,0xE0,0x00,0x00,0x0F,0xF0,0x08,0x10,0x10,0x08,0x20,0x04,0x40,0x02,0x40,0x02,0x7F,0xFE,0x00,0x00,0x00,0x00},		/*	(2)mute */
	{0x00,0x00,0x00,0x00,0x00,0x00,0x03,0xE0,0x00,0x32,0x3F,0x92,0x40,0x4A,0x40,0x4E,0x40,0x4E,0x40,0x4A,0x3F,0x92,0x00,0x32,0x03,0xE0,0x00,0x00,0x00,0x00,0x00,0x00},		/*	(3)biyin */
	{0x00,0x00,0x0F,0xF0,0x14,0x48,0x24,0x44,0x3F,0xFC,0x44,0x42,0x44,0x42,0x7F,0xFE,0x44,0x42,0x44,0x42,0x3F,0xFC,0x24,0x44,0x14,0x48,0x0F,0xF0,0x00,0x00,0x00,0x00},		/*	(4)GK	*/
	{0x00,0x80,0x3E,0x80,0x22,0x80,0x23,0x80,0x22,0x80,0x3E,0xBE,0x00,0xA2,0x00,0xE2,0x00,0xA2,0x3E,0xBE,0x22,0x80,0x23,0x80,0x22,0x80,0x3E,0x80,0x00,0x80,0x00,0x00},		/*	(5)net	*/
		{0x00,0x00,0x1F,0xE0,0x20,0x10,0x20,0x10,0x20,0x14,0x20,0x14,0x20,0x14,0x20,0x1C,0x21,0x1C,0x23,0x94,0x23,0x94,0x21,0x14,0x21,0x10,0x21,0x10,0x19,0x20,0x00,0x00},		/*	(1)send */
//	{0x00,0x00,0x9F,0xE0,0xE0,0x10,0x60,0x10,0x30,0x14,0x38,0x14,0x2C,0x14,0x26,0x1C,0x23,0x1C,0x21,0x94,0x21,0xD4,0x21,0x74,0x23,0xB0,0x23,0x98,0x19,0x2C,0x00,0x04},		/*	(6) reveive */
	{0x00,0x00,0x47,0xE0,0x64,0x20,0x34,0x20,0x1F,0xE0,0x0C,0x00,0x0F,0xF0,0x0B,0x10,0x11,0x88,0x20,0xC4,0x40,0x62,0x40,0x32,0x7F,0xFE,0x00,0x0C,0x00,0x06,0x00,0x02},		/*	(7)no mute */
	{0x00,0x00,0x40,0x00,0x60,0x00,0x33,0xE0,0x18,0x32,0x3F,0x92,0x46,0x4A,0x43,0x4E,0x41,0xCE,0x40,0xCA,0x3F,0xF2,0x00,0x32,0x03,0xF8,0x00,0x0C,0x00,0x06,0x00,0x02},		/*	(8)no biyin*/
	{0x00,0x00,0x40,0x00,0x6F,0xF0,0x34,0x48,0x3C,0x44,0x3F,0xFC,0x46,0x42,0x47,0x42,0x7F,0xFE,0x44,0xC2,0x44,0x62,0x3F,0xFC,0x24,0x5C,0x14,0x4C,0x0F,0xF6,0x00,0x02},		/*	(9)no GK   */
	{0x80,0x00,0xC0,0x80,0x7E,0x80,0x32,0x80,0x3B,0x80,0x2E,0x80,0x3E,0xBE,0x03,0xA2,0x01,0xE2,0x00,0xE2,0x3E,0xFE,0x22,0xB0,0x23,0x98,0x22,0x8C,0x3E,0x84,0x00,0x80},		/*	(10)no net */
	{0x00,0x00,0x1F,0xE0,0x20,0x10,0x20,0x10,0x20,0x14,0x20,0x14,0x20,0x14,0x20,0x1C,0x20,0x1C,0x20,0x14,0x20,0x14,0x20,0x14,0x20,0x10,0x20,0x10,0x1F,0xE0,0x00,0x00},		/*	(11)show */	

	

};

const unsigned char Ascii_1[][5]={	

	{0x00,0x60,0x60,0x00,0x00},		//   ( 1)  . - 0x002E Full Stop
	{0x3E,0x51,0x49,0x45,0x3E},		//   ( 2)  0 - 0x0030 Digit Zero
	{0x00,0x42,0x7F,0x40,0x00},		//   ( 3)  1 - 0x0031 Digit One
	{0x42,0x61,0x51,0x49,0x46},		//   ( 4)  2 - 0x0032 Digit Two
	{0x21,0x41,0x45,0x4B,0x31},		//   ( 5)  3 - 0x0033 Digit Three
	{0x18,0x14,0x12,0x7F,0x10},		//   ( 6)  4 - 0x0034 Digit Four
	{0x27,0x45,0x45,0x45,0x39},		//   ( 7)  5 - 0x0035 Digit Five
	{0x3C,0x4A,0x49,0x49,0x30},		//   ( 8)  6 - 0x0036 Digit Six
	{0x01,0x71,0x09,0x05,0x03},		//   ( 9)  7 - 0x0037 Digit Seven
	{0x36,0x49,0x49,0x49,0x36},		//   ( 10)  8 - 0x0038 Digit Eight
	{0x06,0x49,0x49,0x29,0x1E},		//   ( 11)  9 - 0x0039 Dight Nine
//	{0x00,0x36,0x36,0x00,0x00},		//   ( 12)  : - 0x003A Colon
//	{0x00,0x41,0x7F,0x41,0x00},		//   ( 13)  I - 0x0049 Latin Capital Letter I
//	{0x7F,0x09,0x09,0x09,0x06},		//   ( 14)  P - 0x0050 Latin Capital Letter P
};

#pragma memory = default

#if 0
unsigned char Ascii_2[107][5]={

	{0x7E,0x11,0x11,0x11,0x7E},
};
#endif
static void oled_uDelay(char i)
{
	while(i--);
}

void oled_Delay(char n)
{
      char k;

	for(k = 0; k < n; k++)
	{
        oled_uDelay(1);	
	}
}

static void oled_i2cInit(void)
{
    SET_SDA_OUT();
    oled_uDelay(OLED_DELAY_NUM_C);
	
    SET_SDA_HIGH();
    oled_uDelay(OLED_DELAY_NUM_C);
	
    SET_SCL_OUT();
    oled_uDelay(OLED_DELAY_NUM_C);
	
    SET_SCL_HIGH();
    oled_uDelay(OLED_DELAY_NUM_C);
	
    return;
}

static void oled_gpioInit(void)
{
	SET_VDDH_OUT();	
	SET_VDD_OUT();
	SET_RESET_OUT();
    oled_uDelay(OLED_DELAY_NUM_A);

	SET_RESET_LOW();
	oled_uDelay(OLED_DELAY_NUM_A);
	SET_VDDH_LOW();	
    oled_uDelay(OLED_DELAY_NUM_A);
		
	SET_VDD_HIGH();
	oled_uDelay(OLED_DELAY_NUM_A);
	
	SET_RESET_HIGH()
    oled_uDelay(OLED_DELAY_NUM_A);	
	
	oled_i2cInit();
}

/*****************************************************************************
 �� �� ��  : oled_i2cRw
 ��������  : Read/Write Sequence
 �������  :
 �������  : ��
 �� �� ֵ  : 
 ���ú���  : 
 ��������  : 
 
 �޸���ʷ      :
  1.��    ��   : 2014��3��28��
    ��    ��   : lidaqiang
    �޸�����   : �����ɺ���

*****************************************************************************/
static void oled_i2cRw(unsigned char ucCmd)
{	
	char ucCmdLen = OLED_I2C_CMD_LEN;

	while(ucCmdLen--)
	{
		//add by ldq LED1_RED=~LED1_RED;
		if(ucCmd & 0x80)
		{
			SET_SDA_HIGH();
			
		}
		else
		{
			SET_SDA_LOW();			
		}
		
		oled_uDelay(OLED_DELAY_NUM_A);
		SET_SCL_HIGH();
		oled_uDelay(OLED_DELAY_NUM_A);
		SET_SCL_LOW();
		oled_uDelay(OLED_DELAY_NUM_A);
		ucCmd = ucCmd << 1;
	}
}

static void oled_i2cAck(void)
{
    SET_SDA_IN();
	SET_SCL_HIGH();
	oled_uDelay(OLED_DELAY_NUM_A);
      
	if((P3IN & BIT3) == 0)
	{
          SET_LED_LOW();
    }	
    else
    {
      SET_LED_OUT();
      SET_LED_HIGH();
    }
	
	SET_SCL_LOW();
    SET_SDA_OUT();
	oled_uDelay(OLED_DELAY_NUM_A);
}

/*void I2C_NAck()
{
	SDA=0;
	uDelay(3);
	SCL=1;
	uDelay(3);
	SCL=0;
	uDelay(3);
}*/

static void oled_i2cStart(void) 
{
	SET_SDA_HIGH();
	oled_uDelay(OLED_DELAY_NUM_C);
	SET_SCL_HIGH();
	oled_uDelay(OLED_DELAY_NUM_C);
	SET_SDA_LOW();
	oled_uDelay(OLED_DELAY_NUM_C);
	SET_SCL_LOW();
	oled_uDelay(OLED_DELAY_NUM_C);
	oled_i2cRw(0x78);
	oled_i2cAck();	
}

/*void I2C_Start()
{
	SDA=0;
	uDelay(3);
	SCL=1;
	uDelay(3);
	SCL=0;
	uDelay(3);
	I2C_O(0x78);
	I2C_Ack();
}*/

static void oled_i2cStop(void)
{
	SET_SCL_LOW();
	oled_uDelay(OLED_DELAY_NUM_A);
	SET_SDA_LOW();
	oled_uDelay(OLED_DELAY_NUM_A);
	SET_SCL_HIGH();
	oled_uDelay(OLED_DELAY_NUM_A);

	SET_SDA_HIGH()
	oled_uDelay(OLED_DELAY_NUM_A);
}

static void oled_writeCmd( volatile unsigned char ucValue)
{
	oled_i2cStart();
 	oled_i2cRw(0x00);
 	oled_i2cAck();
	oled_i2cRw(ucValue);
	oled_i2cAck();
	oled_i2cStop();
}
#if 0
static void oled_writeData( volatile unsigned char ucValue)
{
	oled_i2cStart();
	oled_i2cRw(0x40);
	oled_i2cAck();
	oled_i2cRw(ucValue);
	oled_i2cAck();
	oled_i2cStop();
}
#endif
/************************************************************************/
/*	Instruction Setting													*/
/************************************************************************/

static void oled_setStartColumn(unsigned char ucValue)
{
	oled_writeCmd(0x00 + ucValue % 16);		// Set Lower Column Start Address for Page Addressing Mode
						//   Default => 0x00
	oled_writeCmd(0x10 + ucValue / 16);		// Set Higher Column Start Address for Page Addressing Mode
						//   Default => 0x10
}

static void oled_setAddressingMode(unsigned char ucValue)
{
	oled_writeCmd(0x20);			// Set Memory Addressing Mode
	oled_writeCmd(ucValue);			//   Default => 0x02
						//     0x00 => Horizontal Addressing Mode
						//     0x01 => Vertical Addressing Mode
						//     0x02 => Page Addressing Mode
}

#if 0
static void oled_setColumnAddress(unsigned char a, unsigned char b)
{
	oled_writeCmd(0x21);			// Set Column Address
	oled_writeCmd(a);			//   Default => 0x00 (Column Start Address)
	oled_writeCmd(b);			//   Default => 0x7F (Column End Address)
}


static void oled_setPageAddress(unsigned char a, unsigned char b)
{
	oled_writeCmd(0x22);			// Set Page Address
	oled_writeCmd(a);			//   Default => 0x00 (Page Start Address)
	oled_writeCmd(b);			//   Default => 0x07 (Page End Address)
}
#endif

static void oled_setStartLine(unsigned char ucValue)
{
	oled_writeCmd(0x40 | ucValue);			// Set Display Start Line
						//   Default => 0x40 (0x00)
}

static void oled_setContrastControl(unsigned char d)
{
	oled_writeCmd(0x81);			// Set Contrast Control for Bank 0
	oled_writeCmd(d);			//   Default => 0x7F
}

static void oled_setSegmentRemap(unsigned char d)
{
	oled_writeCmd(d);			// Set Segment Re-Map
						//   Default => 0xA0
						//     0xA0 => Column Address 0 Mapped to SEG0
						//     0xA1 => Column Address 0 Mapped to SEG127
}

static void oled_setEntireDisplay(unsigned char d)
{
	oled_writeCmd(d);			// Set Entire Display On / Off
						//   Default => 0xA4
						//     0xA4 => Normal Display
						//     0xA5 => Entire Display On
}

static void oled_setInverseDisplay(unsigned char d)
{
	oled_writeCmd(d);			// Set Inverse Display On/Off
						//   Default => 0xA6
						//     0xA6 => Normal Display
						//     0xA7 => Inverse Display On
}

static void oled_setMultiplexRatio(unsigned char d)
{
	oled_writeCmd(0xA8);			// Set Multiplex Ratio
	oled_writeCmd(d);			//   Default => 0x3F (1/64 Duty)
}

static void oled_setDisplayOnOff(unsigned char d)	
{
	oled_writeCmd(d);			// Set Display On/Off
						//   Default => 0xAE
						//     0xAE => Display Off
						//     0xAF => Display On
}

static void oled_setStartPage(unsigned char d)
{
	oled_writeCmd(0xB0|d);			// Set Page Start Address for Page Addressing Mode
						//   Default => 0xB0 (0x00)
}

#if 0
static void oled_setCommonRemap(unsigned char d)
{
	oled_writeCmd(d);			// Set COM Output Scan Direction
						//   Default => 0xC0
						//     0xC0 => Scan from COM0 to 63
						//     0xC8 => Scan from COM63 to 0
}
#endif
static void oled_setDisplayOffset(unsigned char d)
{
	oled_writeCmd(0xD3);			// Set Display Offset
	oled_writeCmd(d);			//   Default => 0x00
}

static void oled_setDisplayClock(unsigned char d)
{
	oled_writeCmd(0xD5);			// Set Display Clock Divide Ratio / Oscillator Frequency
	oled_writeCmd(d);			//   Default => 0x70
						//     D[3:0] => Display Clock Divider
						//     D[7:4] => Oscillator Frequency
}

static void oled_setLowPower(unsigned char d)
{
	oled_writeCmd(0xD8);			// Set Low Power Display Mode
	oled_writeCmd(d);			//   Default => 0x04 (Normal Power Mode)
}

static void oled_setPrechargePeriod(unsigned char d)
{
	oled_writeCmd(0xD9);			// Set Pre-Charge Period
	oled_writeCmd(d);			//   Default => 0x22 (2 Display Clocks [Phase 2] / 2 Display Clocks [Phase 1])
						//     D[3:0] => Phase 1 Period in 1~15 Display Clocks
						//     D[7:4] => Phase 2 Period in 1~15 Display Clocks
}

static void oled_setCommonConfig(unsigned char d)
{
	oled_writeCmd(0xDA);			// Set COM Pins Hardware Configuration
	oled_writeCmd(d);			//   Default => 0x12
						//     Alternative COM Pin Configuration
						//     Disable COM Left/Right Re-Map
}

static void oled_setVCOMH(unsigned char d)
{
	oled_writeCmd(0xDB);			// Set VCOMH Deselect Level
	oled_writeCmd(d);			//   Default => 0x34 (0.78*VCC)
}

#if 0
static void oled_set_NOP(void)
{
	oled_writeCmd(0xE3);			// Command for No Operation
}
#endif

static void oled_setCommandLock(unsigned char d)
{
	oled_writeCmd(0xFD);			// Set Command Lock
	oled_writeCmd(d);			//   Default => 0x12
						//     0x12 => Driver IC interface is unlocked from entering command.
						//     0x16 => All Commands are locked except 0xFD.
}

static unsigned char oled_reversBit(unsigned char ucValue)
{

    static unsigned char sta[16] ={
        0x00,0x08,0x04,0x0C,0x02,0x0A,0x06,0x0E,0x01,0x09,0x05,0x0D,0x03,0x0B,0x07,0x0F
    };

    unsigned char ucResult = 0; //û���ж�
    ucResult |= (sta[ucValue & 0xF]) << 4;
    ucResult |= sta[ucValue >> 4];
	
    return ucResult;
}

/************************************************************************/
/*	Show Regular Pattern (Full Screen)													*/
/************************************************************************/

void OLED_fillRam(unsigned char ucData)
{
	int i,j;

	for(i = 0; i < OLED_LINE_OF_PAGE; i++)
	{
		oled_setStartPage(i);
		oled_setStartColumn(0x00);

		oled_i2cStart();
		oled_i2cRw(0x40);
		oled_i2cAck();

		for(j = 0; j < 128; j++)
		{
			oled_i2cRw(ucData);
			oled_i2cAck();
		}

		oled_i2cStop();
	}
}

/*****************************************************************************
 �� �� ��  : Fill_Block
 ��������  : Show Regular Pattern (Partial or Full Screen)
 �������  :
 �������  : ��
 �� �� ֵ  : 
 ���ú���  : 
 ��������  : 
 
 �޸���ʷ      :
  1.��    ��   : 2014��3��28��
    ��    ��   : lidaqiang
    �޸�����   : �����ɺ���

*****************************************************************************/
static void Fill_Block(unsigned char Data, unsigned char a, unsigned char b, 
	unsigned char c, unsigned char d)
{
	unsigned char i,j;
	
	for(i = a; i < (b + 1); i++)
	{
		oled_setStartPage(i);
		oled_setStartColumn(c);

		oled_i2cStart();
		oled_i2cRw(0x40);
		oled_i2cAck();

		for(j = 0; j < d; j++)
		{
			oled_i2cRw(Data);
			oled_i2cAck();
		}

		oled_i2cStop();
	}
}

#if 0

/*****************************************************************************
 �� �� ��  : Checkerboard
 ��������  : Show Checkboard (Full Screen)
 �������  :
 �������  : ��
 �� �� ֵ  : 
 ���ú���  : 
 ��������  : 
 
 �޸���ʷ      :
  1.��    ��   : 2014��3��28��
    ��    ��   : lidaqiang
    �޸�����   : �����ɺ���

*****************************************************************************/
void Checkerboard(void)
{
	unsigned char i,j;
	
	for(i = 0; i < 8; i++)
	{
		oled_setStartPage(i);
		oled_setStartColumn(0x00);

		oled_i2cStart();
		oled_i2cRw(0x40);
		oled_i2cAck();

		for(j = 0; j < 64; j++)
		{
			oled_i2cRw(0x55);
			oled_i2cAck();
			oled_i2cRw(0xaa);
			oled_i2cAck();
		}

		oled_i2cStop();
	}
}


/*****************************************************************************
 �� �� ��  : Frame
 ��������  : Show Frame (Full Screen)
 �������  :
 �������  : ��
 �� �� ֵ  : 
 ���ú���  : 
 ��������  : 
 
 �޸���ʷ      :
  1.��    ��   : 2014��3��28��
    ��    ��   : lidaqiang
    �޸�����   : �����ɺ���

*****************************************************************************/
void Frame()
{
	unsigned char i,j;
	
	oled_setStartPage(0x00);
	oled_setStartColumn(XLevel);

	oled_i2cStart();
	oled_i2cRw(0x40);
	oled_i2cAck();

	for(i = 0; i < OLED_Max_COLUMN; i++)
	{
		oled_i2cRw(0x01);
		oled_i2cAck();
	}

	oled_i2cStop();
	oled_setStartPage(0x07);
	oled_setStartColumn(XLevel);

	oled_i2cStart();
	oled_i2cRw(0x40);
	oled_i2cAck();

	for(i = 0; i < OLED_Max_COLUMN; i++)
	{
		oled_i2cRw(0x80);
		oled_i2cAck();
	}

	oled_i2cStop();

	for(i = 0; i < 8; i++)
	{
		oled_setStartPage(i);
		for(j = 0; j < OLED_Max_COLUMN; j += (OLED_Max_COLUMN-1))
		{
			oled_setStartColumn(XLevel + j);
			oled_writeData(0xFF);
		}
	}
}
#endif

static void oled_print_font(unsigned char choice, unsigned char fontSel, 
	unsigned char disPos, unsigned char startPage, unsigned char startColum)
{
		unsigned char *srcPoint;
		unsigned char *tmpPoint;
		unsigned char i;
	
		switch(choice)
		{
#if 0			
			case 1:
				srcPoint=(unsigned char *)&Ascii_1[(fontSel-1)][0];
				break;
#endif				
			case 2:
				srcPoint=(unsigned char *)&Ascii_2[(fontSel-1)][0];
				break;
			case 3:
				srcPoint=(unsigned char *)&Ascii_3[(fontSel-1)][0];
				break;
		}

		tmpPoint = srcPoint;
		oled_setStartPage(startPage);
		oled_setStartColumn(startColum);

		oled_i2cStart();
		oled_i2cRw(0x40);
		oled_i2cAck();

		
		for(i = 0; i < disPos; i++)
		{
			oled_i2cRw(oled_reversBit(*tmpPoint));
			oled_i2cAck();
			tmpPoint += 2;
		}

		oled_i2cRw(0x00);
		oled_i2cAck();
		oled_i2cStop();		
		oled_setStartPage(startPage + 1);
		oled_setStartColumn(startColum);

		oled_i2cStart();
		oled_i2cRw(0x40);
		oled_i2cAck();

		tmpPoint = srcPoint + 1;
		for(i = 0; i < disPos; i++)
		{
			oled_i2cRw(oled_reversBit(*tmpPoint));
			oled_i2cAck();
			tmpPoint += 2;
		}

		oled_i2cRw(0x00);
		oled_i2cAck();

		oled_i2cStop();


}

/*****************************************************************************
 �� �� ��  : Show_Font57
 ��������  : Show Character (5x7)
 �������  : a: Database b: Ascii c: Start Page d: Start Column
 �������  : ��
 �� �� ֵ  : 
 ���ú���  : 
 ��������  : 
 
 �޸���ʷ      :
  1.��    ��   : 2014��3��28��
    ��    ��   : lidaqiang
    �޸�����   : �����ɺ���

*****************************************************************************/
void Show_Font57(unsigned char a, unsigned char b, unsigned char c, unsigned char d)
{
	unsigned char *Src_Pointer;
	unsigned char i;

	switch(a)
	{
		case 1:
			Src_Pointer=(unsigned char *)&Ascii_1[(b-1)][0];
			break;
#if 0			
		case 2:
			Src_Pointer=&Ascii_2[(b-1)][0];
			break;
#endif			
	}
	
	oled_setStartPage(c);
	oled_setStartColumn(d);

	oled_i2cStart();
	oled_i2cRw(0x40);
	oled_i2cAck();

	for(i = 0; i < 5; i++)
	{
		oled_i2cRw(*Src_Pointer);
		oled_i2cAck();
		Src_Pointer++;
	}
	oled_i2cRw(0x00);
	oled_i2cAck();

	oled_i2cStop();
}
#if 0

/*****************************************************************************
 �� �� ��  : Show_Font8x16
 ��������  : Show Character (8x16)
 �������  : a: Database b: Ascii c: Start Page d: Start Column
 �������  : ��
 �� �� ֵ  : 
 ���ú���  : 
 ��������  : 
 
 �޸���ʷ      :
  1.��    ��   : 2014��3��28��
    ��    ��   : lidaqiang
    �޸�����   : �����ɺ���

*****************************************************************************/
void Show_Font8x16(unsigned char b, unsigned char c, unsigned char d)
{
	unsigned char *Src_Pointer;
	unsigned char i;

	Src_Pointer=(unsigned char *)&Ascii_test[(b-1)][0];
	oled_setStartPage(c);
	oled_setStartColumn(d);

	oled_i2cStart();
	oled_i2cRw(0x40);
	oled_i2cAck();

	for(i = 0; i < 8; i++)
	{
		oled_i2cRw(oled_reversBit(*Src_Pointer));
		oled_i2cAck();
		Src_Pointer += 2;
	}

	oled_i2cRw(0x00);
	oled_i2cAck();

	oled_i2cStop();

	oled_setStartPage(c + 1);
	oled_setStartColumn(d);

	oled_i2cStart();
	oled_i2cRw(0x40);
	oled_i2cAck();
	
	Src_Pointer	= (unsigned char *)&Ascii_test[(b-1)][0] + 1;
	for(i = 0; i < 8; i++)
	{
		oled_i2cRw(oled_reversBit(*Src_Pointer));
		oled_i2cAck();
		Src_Pointer += 2;
	}

	oled_i2cRw(0x00);
	oled_i2cAck();

	oled_i2cStop();
}

void oled_print_font(unsigned char b, unsigned char c, unsigned char d)
{
	unsigned char *Src_Pointer;
	unsigned char i;

	Src_Pointer=(unsigned char *)&Ascii_test2[(b-1)][0];
	oled_setStartPage(c);
	oled_setStartColumn(d);

	oled_i2cStart();
	oled_i2cRw(0x40);
	oled_i2cAck();

	for(i = 0; i < 16; i++)
	{
		oled_i2cRw(oled_reversBit(*Src_Pointer));
		oled_i2cAck();
		Src_Pointer += 2;
	}

	oled_i2cRw(0x00);
	oled_i2cAck();

	oled_i2cStop();

	oled_setStartPage(c + 1);
	oled_setStartColumn(d);

	oled_i2cStart();
	oled_i2cRw(0x40);
	oled_i2cAck();
	
	Src_Pointer	= (unsigned char *)&Ascii_test2[(b-1)][0] + 1;
	for(i = 0; i < 16; i++)
	{
		oled_i2cRw(oled_reversBit(*Src_Pointer));
		oled_i2cAck();
		Src_Pointer += 2;
	}

	oled_i2cRw(0x00);
	oled_i2cAck();

	oled_i2cStop();
}

//-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
void oled_print_words(unsigned char *Data_Pointer, unsigned char b, unsigned char c)
{
	unsigned char *Src_Pointer;

	Src_Pointer=Data_Pointer;
	Show_Font57(1,96,b,c);			// No-Break Space
						//   Must be written first before the string start...

	while(1)
	{
		oled_print_font(*Src_Pointer, b, c);
		Src_Pointer++;
		c += 16;
		if(*Src_Pointer == 0)
		{
			break;
		}
	}
}
#endif

void oled_print_string(unsigned char *Data_Pointer, unsigned char b, unsigned char c, unsigned char  d)
{
	unsigned char *Src_Pointer;

	Src_Pointer=Data_Pointer;
	//Show_Font57(1,96,b,c);			// No-Break Space
						//   Must be written first before the string start...

	while(d--)
	{
		if (*Src_Pointer == 0x20)
		{
			c += 8;			
			Src_Pointer++;
			continue;
		}
		
		//Show_Font8x16(*Src_Pointer, b, c);

		oled_print_font(3, *Src_Pointer, 8, b, c);
		Src_Pointer++;
		c += 8;
		if(*Src_Pointer == 0x30)
		{
			break;
		}
	}
}

void oled_print_pics(unsigned char *Data_Pointer, unsigned char b, unsigned char c)
{
	unsigned char *Src_Pointer;

	Src_Pointer=Data_Pointer;
	//Show_Font57(1,96,b,c);			// No-Break Space
						//   Must be written first before the string start...
	//while(1)
	{
		if (*Src_Pointer == 0x35)
		{
			c += 24;			
			Src_Pointer++;
			return;
		}
		
//		oled_print_font(*Src_Pointer, b, c);
		oled_print_font(2, *Src_Pointer, 16, b, c);
		Src_Pointer++;
		c += 24;
		if(*Src_Pointer == 0)
		{
			return;
		}
	}
}

/*****************************************************************************
 �� �� ��  : Show_String
 ��������  : Show_String
 �������  : a: Database b: Start Page c: Start Column 
 			 * Must write "0" in the end...
 �������  : ��
 �� �� ֵ  : 
 ���ú���  : 
 ��������  : 
 
 �޸���ʷ      :
  1.��    ��   : 2014��3��28��
    ��    ��   : lidaqiang
    �޸�����   : �����ɺ���

*****************************************************************************/
void Show_String(unsigned char a, unsigned char *Data_Pointer, unsigned char b, unsigned char c)
{
	unsigned char *Src_Pointer;

	Src_Pointer=Data_Pointer;
	//Show_Font57(1,15,b,c);			// No-Break Space
						//   Must be written first before the string start...

	while(1)
	{
		Show_Font57(a, *Src_Pointer, b, c);
		Src_Pointer++;
		c+=6;
		if(*Src_Pointer == 0)
		{
			break;
		}
	}
}
#if 0

//-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
//  Show Pattern (Partial or Full Screen)
//
//    a: Start Page
//    b: End Page
//    c: Start Column
//    d: Total Columns
//-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
void Show_Pattern(unsigned char *Data_Pointer, unsigned char a, unsigned char b, 
	unsigned char c, unsigned char d)
{
	unsigned char *Src_Pointer;
	unsigned char i,j;

	Src_Pointer = Data_Pointer;
	for(i = a; i < (b + 1); i++)
	{
		oled_setStartPage(i);
		oled_setStartColumn(c);

		oled_i2cStart();
		oled_i2cRw(0x40);
		oled_i2cAck();

		for(j = 0; j < d; j++)
		{
			oled_i2cRw(*Src_Pointer);
			oled_i2cAck();
			Src_Pointer++;
		}

		oled_i2cStop();
	}
}

//-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
//  Vertical / Fade Scrolling (Partial or Full Screen)
//
//    a: Scrolling Direction
//       "0x00" (Upward)
//       "0x01" (Downward)
//    b: Set Top Fixed Area
//    c: Set Vertical Scroll Area
//    d: Set Numbers of Row Scroll per Step
//    e: Set Time Interval between Each Scroll Step
//-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
void Vertical_Scroll(unsigned char a, unsigned char b, unsigned char c, unsigned char d, unsigned char e)
{
	unsigned int i,j;	

	oled_writeCmd(0xA3);			// Set Vertical Scroll Area
	oled_writeCmd(b);			//   Default => 0x00 (Top Fixed Area)
	oled_writeCmd(c);			//   Default => 0x40 (Vertical Scroll Area)

	switch(a)
	{
		case 0:
			for(i = 0; i < c; i += d)
			{
				oled_setStartLine(i);
				for(j = 0; j < e; j++)
				{
					oled_uDelay(200);
				}
			}
			break;
		case 1:
			for(i = 0; i < c; i += d)
			{
				oled_setStartLine(c - i);
				for(j = 0; j < e; j++)
				{
					oled_uDelay(200);
				}
			}
			break;
	}
	oled_setStartLine(0x00);
}

//-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
//  Continuous Horizontal Scrolling (Partial or Full Screen)
//
//    a: Scrolling Direction
//       "0x00" (Rightward)
//       "0x01" (Leftward)
//    b: Define Start Page Address
//    c: Define End Page Address
//    d: Define Start Column Address
//    e: Define End Column Address
//    f: Set Time Interval between Each Scroll Step in Terms of Frame Frequency
//    g: Delay Time
//-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
void Horizontal_Scroll(unsigned char a, unsigned char b, unsigned char c, unsigned char d, unsigned char e, unsigned char f, unsigned char g)
{
	oled_writeCmd(0x26 | a);			// Horizontal Scroll Setup
	oled_writeCmd(0x00);
	oled_writeCmd(b);
	oled_writeCmd(f);
	oled_writeCmd(c);
	oled_writeCmd(0x00);
	oled_writeCmd(d);
	oled_writeCmd(e);
	oled_writeCmd(0x2F);			// Activate Scrolling
	oled_Delay(g);
}

//-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
//  Continuous Vertical / Horizontal / Diagonal Scrolling (Partial or Full Screen)
//
//    a: Scrolling Direction
//       "0x00" (Vertical & Rightward)
//       "0x01" (Vertical & Leftward)
//    b: Set Numbers of Column Scroll per Step (Horizontal / Diagonal Scrolling)
//       "0x00" (Horizontal / Diagonal Scrolling Off)
//       "0x01" (Horizontal / Diagonal Scrolling by 1 Column)
//    c: Define Start Row Address (Horizontal / Diagonal Scrolling)
//    d: Define End Page Address (Horizontal / Diagonal Scrolling)
//    e: Define Start Column Address
//    f: Define End Column Address
//    g: Set Top Fixed Area (Vertical Scrolling)
//    h: Set Vertical Scroll Area (Vertical Scrolling)
//    i: Set Numbers of Row Scroll per Step (Vertical / Diagonal Scrolling)
//    j: Set Time Interval between Each Scroll Step in Terms of Frame Frequency
//    k: Delay Time
//    * e+f must be less than or equal to the Multiplex Ratio...
//-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
void Continuous_Scroll(unsigned char a, unsigned char b, unsigned char c, unsigned char d, unsigned char e, unsigned char f, unsigned char g, unsigned char h, unsigned char i, unsigned char j, unsigned char k)
{
	oled_writeCmd(0xA3);			// Set Vertical Scroll Area
	oled_writeCmd(g);			//   Default => 0x00 (Top Fixed Area)
	oled_writeCmd(h);			//   Default => 0x40 (Vertical Scroll Area)

	oled_writeCmd(0x29 + a);			// Continuous Vertical & Horizontal Scroll Setup
	oled_writeCmd(b);
	oled_writeCmd(c);
	oled_writeCmd(j);
	oled_writeCmd(d);
	oled_writeCmd(i);
	oled_writeCmd(e);
	oled_writeCmd(f);
	oled_writeCmd(0x2F);			// Activate Scrolling
	oled_Delay(k);
}

//-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
//  Deactivate Scrolling (Full Screen)
//-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
void Deactivate_Scroll()
{
	oled_writeCmd(0x2E);			// Deactivate Scrolling
}

//-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
//  Fade In (Full Screen)
//-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
void Fade_In()
{
	unsigned int i;	

	for(i = 0; i < (OLED_BRIGHTNESS + 1); i++)
	{
		oled_setContrastControl(i);
		oled_uDelay(200);
		oled_uDelay(200);
		oled_uDelay(200);
	}
}

//-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
//  Fade Out (Full Screen)
//-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
void Fade_Out()
{
	unsigned int i;	

	for(i = (OLED_BRIGHTNESS + 1); i > 0; i--)
	{
		oled_setContrastControl(i-1);
		oled_uDelay(200);
		oled_uDelay(200);
		oled_uDelay(200);
	}
	
	oled_setDisplayOnOff(0xAE);
}

//-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
//  Sleep Mode
//
//    "0x00" Enter Sleep Mode
//    "0x01" Exit Sleep Mode
//-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
void Sleep(unsigned char a)
{
	switch(a)
	{
		case 0:
			oled_setDisplayOnOff(0xAE);
			oled_setEntireDisplay(0xA5);
			break;
		case 1:
			oled_setEntireDisplay(0xA4);
			oled_setDisplayOnOff(0xAF);
			break;
	}
}
#endif

//-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
//  Connection Test
//-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
#if 0
void Test()
{
	unsigned char i;

	RES=0;
	for(i=0;i<200;i++)
	{
		oled_uDelay(200);
	}
	RES=1;

	oled_setEntireDisplay(0xA5);		// Enable Entire Display On (0xA4/0xA5)

	while(1)
	{
		oled_setDisplayOnOff(0xAF);	// Display On (0xAE/0xAF)
		oled_Delay(100);
		oled_setDisplayOnOff(0xAE);	// Display Off (0xAE/0xAF)
		oled_Delay(100);
	}
}
#endif

//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
//  Initialization
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
static void oled_init(void)
{
	oled_setCommandLock(0x12);		// Unlock Driver IC (0x12/0x16)
	oled_setDisplayOnOff(0xAE);		// Display Off (0xAE/0xAF)
	oled_setDisplayClock(0xA0);		// Set Clock as 116 Frames/Sec
	oled_setMultiplexRatio(0x3F);	// 1/64 Duty (0x0F~0x3F)
	oled_setDisplayOffset(0x00);	// Shift Mapping RAM Counter (0x00~0x3F)
	oled_setStartLine(0x00);			// Set Mapping RAM Display Start Line (0x00~0x3F)
	oled_setLowPower(0x04);			// Set Normal Power Mode (0x04/0x05)
	//oled_setLowPower(0x05);			// Set Low Power Display Mode (0x04/0x05)
	oled_setAddressingMode(0x02);		// Set Page Addressing Mode (0x00/0x01/0x02)
	oled_setSegmentRemap(0xA1);		// Set SEG/Column Mapping (0xA0/0xA1)
	oled_setSegmentRemap(0xC8);			// Set COM/Row Scan Direction (0xC0/0xC8)
	oled_setCommonConfig(0x12);		// Set Alternative Configuration (0x02/0x12)
	oled_setContrastControl(OLED_BRIGHTNESS);	// Set SEG Output Current
	oled_setPrechargePeriod(0x82);		// Set Pre-Charge as 8 Clocks & Discharge as 2 Clocks
	//Set_Precharge_Period(0x25);		// Set Pre-Charge as 2 Clocks & Discharge as 5 Clocks
	oled_setVCOMH(0x3c);//(0x34);			// Set VCOM Deselect Level
	oled_setEntireDisplay(0xA4);		// Disable Entire Display On (0xA4/0xA5)
	oled_setInverseDisplay(0xA6);		// Disable Inverse Display On (0xA6/0xA7)
	OLED_fillRam(0x00);				// 00  Clear Screen
	SET_VDDH_HIGH();
	oled_Delay(10);
	oled_setDisplayOnOff(0xAF);		// Display On (0xAE/0xAF)
}

void OLED_initDev(void)
{
 	oled_gpioInit();
	oled_init();
}

static void oled_oledPowerOff(void)
{
	SET_VDDH_LOW();	
	oled_uDelay(OLED_DELAY_NUM_A);
	
	SET_VDD_LOW()
    oled_uDelay(OLED_DELAY_NUM_A);	
}

void OLED_deinitDev(void)
{
	oled_setDisplayOnOff(0xAE); 	// Display On (0xAE/0xAF)
	oled_oledPowerOff();
}

void OLED_printLogo(void)
{
	//unsigned char Logo[] = {23, 31, 38, 29, 41, 39, 31, 0x30};
        unsigned char Logo[] = {23, 5, 12, 3, 15, 13, 5, 0x30};
	//oled_print_string(Logo, 0x04, 0x1a, 14);
	oled_print_string(Logo, 0x04, XLevel + 0xa + (13 - 7) * 4, 14);
}

void OLED_updateDisplay(void)
{
	unsigned char value;
	unsigned char ip[17] = {0};
	unsigned char pic[2] = {0};
	unsigned char asc[14] = {0};
	unsigned char len = 0;
	unsigned char len_flag = 1;
	char i = 0;

	/* ��1 ��ʾ�� */
	if (reg_val[oled_req_pic] != 0)
	{
		value = reg_val[oled_pic];
		reg_val[oled_req_pic] = 0x00;
		//Fill_Block(0x00, 0x01, 0x2,  0x0a, 0x10);

		for (i = 0; i < 5; i++)
		{	
			if (value & (0x10 >> i))
			{
				pic[0] = i + 1;
				pic[1] = 0;
			}
			else
			{
				pic[0] = i + 6;
				pic[1] = 0;
			}

			if ((i == 0) && (value & 0x20) == 0)
			{
				pic[0] = 11;
				pic[1] = 0;
			}
			oled_print_pics(pic, 0x01, XLevel + 0xa + (i * 24));	
		}
	}

	if (reg_val[oled_asc] == 0x11)
	{	
		len = 0;
		len_flag = 1;
		reg_val[oled_asc] = 0x00;
		
		for (i = 0; i < 13; i++)
		{
			if ((reg_val[i + 18] >= 'A') && (reg_val[i + 18] <= 'Z'))
			{
				asc[i] = reg_val[i + 18] - 0x41 +  1; 
				if (len_flag == 1)
				{
					len++;
				}
			}
			else if ((reg_val[i + 18] >= 'a') && (reg_val[i + 18] <= 'z'))
			{
				asc[i] = reg_val[i + 18] - 0x61 +  0x1B; 
				if (len_flag == 1)
				{
					len++;
				}
			}
			else 
			{
				asc[i] = reg_val[i + 18];
				if (reg_val[i + 18] == 0x30)
				{
					len_flag = 0;
				}
				if (len_flag == 1)
				{
					len++;
				}
			}
		}
		
		Fill_Block(0x00, 0x04, 0x5, 0xa, 118);
		oled_print_string(asc, 0x04, XLevel + 0xa + (13 - len) * 4, 14);
	}

	if (reg_val[oled_ip] == 0x11)
	{
		reg_val[oled_ip] = 0x00;
		for (i = 0; i < 4; i++)
		{
			value = reg_val[oled_ip_1 + i];
			
			if (value >= 100)
			{
				ip[0 + (i * 4)] = (value / 100) + 2;
				value %= 100;
			}
			else
			{
				ip[0 + (i * 4)] = (value / 100) + 2;
			}
			
			if (value >= 10)
			{
				ip[1 + (i * 4)] = (value /10) + 2;
				value %= 10;
			}
			else
			{
				ip[1 + (i * 4)] = (value /10) + 2;
			}
			
			ip[2 + (i * 4)] = value + 2;
			ip[3 + (i * 4)] = 1;
			
			if (i == 3)
			{
				ip[3 + (i * 4)] = 0;
			}

		}
		/* 0x27 + 15 * 5 */
		Show_String(1,ip,0x07,0x13);
	}

}
#endif

#if 0
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
//  Main Program
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
void main()
{
	unsigned char code Front[] = {11, 12, 13, 14, 0};
	unsigned char code Front1[] = {15, 16, 17, 18, 0};
	//unsigned char code Pic[] = {1, 2, 3, 4, 5, 0};
	unsigned char code Pic[] = {6, 7, 8, 9, 10, 0};
	unsigned char code IP[] = {41,48,26,17,23,18,14,18,21,21,14,18,21,21,14,18,21,21,0};
	unsigned char code irda[] = {33, 0};
	unsigned char code send[] = {19, 20, 21, 22, 23, 24, 0};
	unsigned char code New[] = {1,2,3,4,5,6,7,8,9,10,11,12,13,0};

	P1=0xFF;
	P0=0xFF;//P3 mengxianfu
	SA0=0;//iic address
	OLED_Init();

	oled_print_pics(&Pic, 0x00, XLevel + 0xa);
	Show_Font8x16(1, 0x3, XLevel + 0x78);
	oled_print_string(&New, 0x03, XLevel + 0xa);
	//oled_print_words(&Front, 0x03, XLevel + 0xa);
	Show_String(1,&IP,0x07,0x0a);
#if 0	
	while (1)
	{
		oled_print_words(&Front, 0x03, XLevel + 0xa);
		oled_Delay(100);
		oled_print_words(&send, 0x03, XLevel + 0xa);
		oled_Delay(100);
	}
#endif

while(1)
{
	
	//LED1_GREEN=~LED1_GREEN;
	oled_Delay(100);
}
	
}
#endif


